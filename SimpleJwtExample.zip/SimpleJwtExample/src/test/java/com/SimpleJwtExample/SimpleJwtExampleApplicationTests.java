package com.SimpleJwtExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleJwtExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
