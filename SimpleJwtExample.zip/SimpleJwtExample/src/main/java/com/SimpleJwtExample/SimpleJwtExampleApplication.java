package com.SimpleJwtExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleJwtExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleJwtExampleApplication.class, args);
	}

}
